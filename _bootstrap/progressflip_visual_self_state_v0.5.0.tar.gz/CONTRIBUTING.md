# Contributing

Please keep scientific changes reviewable and reproducible.

1. Add or modify a named condition in `progressflip/conditions.py`.
2. Add policy-free screening and a manipulation check before interpreting outcomes.
3. Encode the comparison direction and hypothesis family in YAML.
4. Add CPU tests for any transformation, action substitution, or analysis rule.
5. Run `python -m pytest -q`, `python -m compileall -q progressflip tests`, and shell syntax checks.
6. Never commit model weights, run outputs, private tokens, or mutable cohort locks.

Prospective result runs require a clean Git commit. Changing source or configuration after a smoke gate invalidates that gate.
