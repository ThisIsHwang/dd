# Environment setup

The repository targets a single 8×H100 node whose NVIDIA driver reports CUDA 12.9. For compatibility with the pinned OpenVLA-OFT evaluation stack, the Python environment uses PyTorch 2.2.0 with the official CUDA 12.1 runtime wheel.

```bash
bash scripts/bootstrap_conda.sh
conda activate progressflip
```

The bootstrap script:

- checks out pinned OpenVLA-OFT and LIBERO revisions;
- pins the OpenVLA Transformers and dlimp Git dependencies;
- installs the OpenVLA-OFT-compatible PyTorch runtime;
- installs headless OpenCV;
- materializes the LIBERO Python path and a default robosuite private-macros module;
- installs this repository with development tests;
- checks imports and dependencies.

The repository itself explicitly detects and merges a local PEFT/LoRA adapter, so no untracked modification to `third_party/openvla-oft` is required.

Before a run:

```bash
export PROGRESSFLIP_GPU_LIST=0,1,2,3,4,5,6,7
export PROGRESSFLIP_RENDER_BACKEND=egl
progressflip-doctor --project-root "$PWD" --expect-gpus 8 --strict
```

For a compute node without EGL:

```bash
export PROGRESSFLIP_RENDER_BACKEND=osmesa
progressflip-doctor --project-root "$PWD" --expect-gpus 8 --strict
```

OSMesa must be installed by the cluster administrator. Rendering moves to the CPU; VLA inference remains on the selected H100.
